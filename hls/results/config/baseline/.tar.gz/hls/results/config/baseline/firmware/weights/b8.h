//Numpy array shape [8]
//Min -1.044151425362
//Max 1.241715908051
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
batch_normalization_1_bias_t b8[8];
#else
batch_normalization_1_bias_t b8[8] = {1.2417159081, -0.7035530210, 1.1768277884, 0.7428480387, 0.2276446819, -0.0504677296, -1.0441514254, -0.0407923758};
#endif

#endif
